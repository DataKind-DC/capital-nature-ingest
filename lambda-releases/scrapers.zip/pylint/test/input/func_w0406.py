"""test module importing itself"""
# pylint: disable=no-absolute-import,using-constant-test
from __future__ import print_function
from . import func_w0406

__revision__ = 0


if __revision__:
    print(func_w0406)
