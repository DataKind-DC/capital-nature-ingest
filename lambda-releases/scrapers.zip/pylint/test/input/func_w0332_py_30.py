"""check use of l as long int marker
"""
# pylint: disable=long-suffix
__revision__ = 1l
