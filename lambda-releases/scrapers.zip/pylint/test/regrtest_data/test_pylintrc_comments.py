def f(x):
 return x # 1 space